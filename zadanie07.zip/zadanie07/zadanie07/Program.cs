﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Ввод числа N
            Console.Write("Введите целое число N: ");
            int N = int.Parse(Console.ReadLine());

            // Вывод чисел от 1 до N
            Console.WriteLine("Числа от 1 до {0}:", N);
            for (int i = 1; i <= N; i++)
            {
                Console.WriteLine(i);
            }
    }
}

